import React, { useEffect, useState } from 'react';
import './App.css';
import CurrencyRow from './CurrencyRow'

const BASE_URL = 'http://api.exchangeratesapi.io/v1/latest?access_key=7b69a8afd47efe9f684f62dfa06bb69d'

function App() {
  const [currencyOptions, setCurrencyOptions] = useState([])
  const [fromCurrency, setFromCurrency] = useState()
  const [toCurrency, setToCurrency] = useState()
  const [exchangeRate, setExchangeRate] = useState()
  const [amount, setAmount] = useState(1)
  /*const [error, setError] = useState()*/
  const [amountInFromCurrency, setAmountInFromCurrency] = useState(true)
  //console.log(data)

  let toAmount = 0, fromAmount = 0
  if (amountInFromCurrency) {
    // console.log(parseInt(amount))
    fromAmount = parseInt(amount)
    toAmount = parseInt(amount) * parseInt(exchangeRate)
  } else {

    toAmount = amount
    fromAmount = amount / parseInt(exchangeRate)
  }

  useEffect(() => {
    fetch(BASE_URL)
      .then(res => res.json())
      .then(data => {
        const firstCurrency = Object.keys(data.rates)[0]
        setCurrencyOptions([...Object.keys(data.rates)])
        setFromCurrency(data.base)
        setToCurrency(firstCurrency)
        setExchangeRate(data.rates[firstCurrency])
      })
      .then(data => console.log(data))
      .catch((error) => {
        console.log(error)
      });
  }, [])

  useEffect(() => {
    if (fromCurrency != null && toCurrency != null) {
      fetch(`${BASE_URL}&base=${fromCurrency}&symbols=${toCurrency}`)
        .then(res => res.json())
        .then(data => setExchangeRate(data.rates[toCurrency]))
        .catch((error) => {
          console.log(error)
        });
    }
  }, [fromCurrency, toCurrency])

  function handleFromAmountChange(e) {
    setAmount( parseInt(e.target.value) || amount)
    setAmountInFromCurrency(true)
  }

  function handleToAmountChange(e) {
    setAmount(
      parseInt(e.target.value) || amount)
    setAmountInFromCurrency(false)
  }

  return (
    <>
      <h1>Convert</h1>
      <CurrencyRow
        currencyOptions={currencyOptions}
        selectedCurrency={fromCurrency}
        onChangeCurrency={e => setFromCurrency(e.target.value)}
        onChangeAmount={handleFromAmountChange}
        amount={fromAmount}
      />
      <div className="equals">=</div>
      <CurrencyRow
        currencyOptions={currencyOptions}
        selectedCurrency={toCurrency}
        onChangeCurrency={e => setToCurrency(e.target.value)}
        onChangeAmount={handleToAmountChange}
        amount={toAmount}
      />
      <div></div>
    </>
  );
}

export default App;
