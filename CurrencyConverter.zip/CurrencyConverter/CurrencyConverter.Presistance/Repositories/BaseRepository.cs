﻿using CurrencyConverter.Application.Contracts.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverter.Presistance.Repositories
{
    public class BaseRepository<T> : IAsyncRepository<T> where T : class
    {
        private CurrencyConverterDbContext _currencyConverterDbContext;

        public BaseRepository(CurrencyConverterDbContext currencyConverterDbContext)
        {
            _currencyConverterDbContext = currencyConverterDbContext;
        }

        public async Task<T> AddAsync(T entity)
        {
            await _currencyConverterDbContext.Set<T>().AddAsync(entity);
            await _currencyConverterDbContext.SaveChangesAsync();

            return entity;
        }

      

        public async Task<T> GetByIdAsync(Guid id)
        {
            return await _currencyConverterDbContext.Set<T>().FindAsync(id);
        }

        public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await _currencyConverterDbContext.Set<T>().ToListAsync();
        }

        public async Task UpdateAsync(T entity)
        {
            _currencyConverterDbContext.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _currencyConverterDbContext.SaveChangesAsync();
        }

      

        public async Task DeleteAsync(T entity)
        {
            _currencyConverterDbContext.Set<T>().Remove(entity);
            await _currencyConverterDbContext.SaveChangesAsync();
        }

       
    }
}
