﻿using CurrencyConverter.Application.Contracts.Persistence;
using CurrencyConverter.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Presistance.Repositories
{
    public class CurrencyDetailRepository : BaseRepository<CurrencyDetail> , ICurrencyDetailRepository
    {
        public CurrencyDetailRepository(CurrencyConverterDbContext dbContext) :base(dbContext)
        {

        }
    }
}
