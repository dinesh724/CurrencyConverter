﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CurrencyConverter.Presistance.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CurrencyDetails",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FromCurrency = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ToCurrency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FromAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ToAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CurrencyDetails", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "CurrencyDetails",
                columns: new[] { "Id", "FromAmount", "FromCurrency", "ToAmount", "ToCurrency" },
                values: new object[] { new Guid("5d8bf118-67ef-48f5-b8b5-d596d87375e3"), 12.5m, "GBP", 13.5m, "USD" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CurrencyDetails");
        }
    }
}
