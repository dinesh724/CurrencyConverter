﻿using CurrencyConverter.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Presistance.Configurations
{
    public class CurrencyDetailConfiguration : IEntityTypeConfiguration<CurrencyDetail>
    {
        public void Configure(EntityTypeBuilder<CurrencyDetail> builder)
        {
            builder.Property(p => p.FromCurrency)
                .IsRequired();
        }
    }
}
