﻿using CurrencyConverter.Domain.Common;
using CurrencyConverter.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CurrencyConverter.Presistance
{
   public class CurrencyConverterDbContext : DbContext
    {
        public CurrencyConverterDbContext(DbContextOptions<CurrencyConverterDbContext> options)
            :base(options)
        {

        }

        public DbSet<CurrencyDetail> CurrencyDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(CurrencyConverterDbContext).Assembly);

            var currencyDetailGuid = Guid.Parse("5d8bf118-67ef-48f5-b8b5-d596d87375e3");

            modelBuilder.Entity<CurrencyDetail>().HasData(
             new CurrencyDetail
             {
                 Id = currencyDetailGuid,
                 FromAmount = 12.5m,
                 FromCurrency ="GBP",
                 ToAmount = 13.5m,
                 ToCurrency = "USD"
             });

            base.OnModelCreating(modelBuilder);
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach (var entry in ChangeTracker.Entries<AuditEntity>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.DateCreated = DateTime.Now;
                        break;
                }
            }

            return base.SaveChangesAsync(cancellationToken);
        }
    }
}
