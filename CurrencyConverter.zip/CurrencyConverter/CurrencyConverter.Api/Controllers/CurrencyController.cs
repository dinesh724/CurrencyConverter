﻿using CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetail;
using CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetailList;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CurrencyConverter.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyController : ControllerBase
    {
        private IMediator _mediator;

        public CurrencyController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("all",Name = "GetAllCurrencyDetails")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<List<CurrencyDetailListDto>>> GetAllCurrencyDetails()
        {
            var dto = await _mediator.Send(new GetCurrencyDetailsListQuery());

            return Ok(dto);
        }

        [HttpGet("{id}", Name = "GetCurrencyDetailsById")]
        public async Task<ActionResult<CurrencyDetailListDto>> GetCurrencyDetails(Guid id)
        {
            var getCurrencyDetailQuery = new GetCurrencyDetailsQuery() { Id = id };
            var dto = await _mediator.Send(new GetCurrencyDetailsQuery());

            return Ok(await _mediator.Send(getCurrencyDetailQuery));
        }
    }
}
