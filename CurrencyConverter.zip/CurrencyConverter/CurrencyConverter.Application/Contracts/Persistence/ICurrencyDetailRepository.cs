﻿using CurrencyConverter.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Contracts.Persistence
{
    public interface ICurrencyDetailRepository : IAsyncRepository<CurrencyDetail>
    {

    }
}
