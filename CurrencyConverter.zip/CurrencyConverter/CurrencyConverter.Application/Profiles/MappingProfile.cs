﻿using AutoMapper;
using CurrencyConverter.Application.Features.CurrencyDetails;
using CurrencyConverter.Application.Features.CurrencyDetails.Commands.CreateCurrencyDetail;
using CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetail;
using CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetailList;
using CurrencyConverter.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<CurrencyDetail, CurrencyDetailListDto>().ReverseMap();
            CreateMap<CurrencyDetail, CurrencyDetailDto>().ReverseMap();
            CreateMap<CurrencyDetail, CreateCurrencyDetailCommand>().ReverseMap();
        }
        
    }
}
