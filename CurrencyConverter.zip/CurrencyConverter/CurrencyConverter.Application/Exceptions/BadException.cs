﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Exceptions
{
    public class BadException : ApplicationException
    {
        public BadException(string message) : base(message)
        {

        }
    }
}
