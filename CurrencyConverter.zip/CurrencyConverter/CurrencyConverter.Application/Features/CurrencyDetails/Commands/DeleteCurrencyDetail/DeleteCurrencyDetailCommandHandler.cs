﻿using AutoMapper;
using CurrencyConverter.Application.Contracts.Persistence;
using CurrencyConverter.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Commands.DeleteCurrencyDetail
{
    public class DeleteCurrencyDetailCommandHandler : IRequestHandler<DeleteCurrencyDetailCommand>
    {
        private IMapper _mapper;
        private IAsyncRepository<CurrencyDetail> _asyncRepository;

        public DeleteCurrencyDetailCommandHandler(IMapper mapper, IAsyncRepository<CurrencyDetail> asyncRepository)
        {
            _mapper = mapper;
            _asyncRepository = asyncRepository;
        }

        public async Task<Unit> Handle(DeleteCurrencyDetailCommand request, CancellationToken cancellationToken)
        {
            var currencyDetailToDelete = await _asyncRepository.GetByIdAsync(request.Id);

            await _asyncRepository.DeleteAsync(currencyDetailToDelete);

            return Unit.Value;
        }
    }
}
