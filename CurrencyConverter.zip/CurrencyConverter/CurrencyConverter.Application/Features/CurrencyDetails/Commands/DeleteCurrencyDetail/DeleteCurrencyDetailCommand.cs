﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Commands.DeleteCurrencyDetail
{
    public class DeleteCurrencyDetailCommand : IRequest
    {
        public Guid Id { get; set; }
    }
}
