﻿using CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetail;
using CurrencyConverter.Application.Responses;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Commands.CreateCurrencyDetail
{
   public class CreateCurrencyDetailCommandResponse : BaseResponse
    {
        public CreateCurrencyDetailCommandResponse() : base()
        {

        }
        public CurrencyDetailDto CurrencyDetail { get; set; }
    }
}
