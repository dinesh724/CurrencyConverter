﻿using AutoMapper;
using CurrencyConverter.Application.Contracts.Persistence;
using CurrencyConverter.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Commands.CreateCurrencyDetail
{
    public class CreateCurrencyDetailCommandHandler : IRequestHandler<CreateCurrencyDetailCommand, Guid>
    {
        private IMapper _mapper;
        private ICurrencyDetailRepository _currencyDetailRepository;

        public CreateCurrencyDetailCommandHandler(IMapper mapper, ICurrencyDetailRepository currencyDetailRepository)
        {
            _mapper = mapper;
            _currencyDetailRepository = currencyDetailRepository;
        }

        public async Task<Guid> Handle(CreateCurrencyDetailCommand request, CancellationToken cancellationToken)
        {
            var currencyDetailCommandResponse = new CreateCurrencyDetailCommandResponse();

            var validator = new CreateCurrencyDetailCommandValidator();
            var validationResult = await validator.ValidateAsync(request);

            if (validationResult.Errors.Count > 0)
            {
                currencyDetailCommandResponse.Success = false;
                currencyDetailCommandResponse.ValidationErrors = new List<string>();
                throw new Exceptions.ValidationException(validationResult);
            }


            var @currencyDetail = _mapper.Map<CurrencyDetail>(request);

            @currencyDetail = await _currencyDetailRepository.AddAsync(@currencyDetail);

            return @currencyDetail.Id;
        }
    }
}
