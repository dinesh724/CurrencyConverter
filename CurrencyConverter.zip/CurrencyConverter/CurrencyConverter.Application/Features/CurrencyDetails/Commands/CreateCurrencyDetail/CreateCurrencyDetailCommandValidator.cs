﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Commands.CreateCurrencyDetail
{
    public class CreateCurrencyDetailCommandValidator : AbstractValidator<CreateCurrencyDetailCommand>
    {
        public CreateCurrencyDetailCommandValidator()
        {
            RuleFor(p => p.FromAmount)
                .NotEmpty().WithMessage("{ParameterName} is required");
            
            RuleFor(p => p.FromCurrency)
                .NotEmpty().WithMessage("{ParameterName} is required");
            
            RuleFor(p => p.ToAmount)
                .NotEmpty().WithMessage("{ParameterName} is required");
            
            RuleFor(p => p.ToCurrency)
                .NotEmpty().WithMessage("{ParameterName} is required");


        }
    }
}
