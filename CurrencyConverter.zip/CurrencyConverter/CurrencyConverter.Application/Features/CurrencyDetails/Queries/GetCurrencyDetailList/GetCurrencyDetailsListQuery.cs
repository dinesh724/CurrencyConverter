﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetailList
{ 
    public class GetCurrencyDetailsListQuery : IRequest<List<CurrencyDetailListDto>>
    {

    }
}
