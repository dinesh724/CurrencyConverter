﻿using AutoMapper;
using CurrencyConverter.Application.Contracts.Persistence;
using CurrencyConverter.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetailList
{
    public class GetCurrencyDetailsListQueryHandler : IRequestHandler<GetCurrencyDetailsListQuery, List<CurrencyDetailListDto>>
    {
        private IMapper _mapper;
        private IAsyncRepository<CurrencyDetail> _currencyDetailRepository;

        public GetCurrencyDetailsListQueryHandler(IMapper mapper , IAsyncRepository<CurrencyDetail> currencyDetailRepository)
        {
            _mapper = mapper;
            _currencyDetailRepository = currencyDetailRepository;
        }

        public async Task<List<CurrencyDetailListDto>> Handle(GetCurrencyDetailsListQuery request, CancellationToken cancellationToken)
        {
            var allCurrencyDetails = (await _currencyDetailRepository.ListAllAsync()).OrderBy(x => x.FromCurrency);

            return _mapper.Map<List<CurrencyDetailListDto>>(allCurrencyDetails);
        }
    }
}
