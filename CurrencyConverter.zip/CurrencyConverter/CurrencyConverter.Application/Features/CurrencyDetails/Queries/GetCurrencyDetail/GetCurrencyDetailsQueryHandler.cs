﻿using AutoMapper;
using CurrencyConverter.Application.Contracts.Persistence;
using CurrencyConverter.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetail
{
    public class GetCurrencyDetailsQueryHandler : IRequestHandler<GetCurrencyDetailsQuery, CurrencyDetailDto>
    {
        private IMapper _mapper;
        private IAsyncRepository<CurrencyDetail> _currencyDetailRepository;

        public GetCurrencyDetailsQueryHandler(IMapper mapper , IAsyncRepository<CurrencyDetail> currencyDetailRepository)
        {
            _mapper = mapper;
            _currencyDetailRepository = currencyDetailRepository;
        }

        public async Task<CurrencyDetailDto> Handle(GetCurrencyDetailsQuery request, CancellationToken cancellationToken)
        {
            var CurrencyDetails = (await _currencyDetailRepository.GetByIdAsync(request.Id));

            return _mapper.Map<CurrencyDetailDto>(CurrencyDetails);
        }
    }
}
