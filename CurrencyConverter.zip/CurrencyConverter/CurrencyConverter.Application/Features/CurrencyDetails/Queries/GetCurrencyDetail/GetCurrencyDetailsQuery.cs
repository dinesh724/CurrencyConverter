﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetail
{
    public class GetCurrencyDetailsQuery : IRequest<CurrencyDetailDto>
    {
        public Guid Id { get; set; }
    }
}
