﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Application.Features.CurrencyDetails.Queries.GetCurrencyDetail
{
    public class CurrencyDetailDto
    {
        public Guid Id { get; set; }

        public string FromCurrency { get; set; }

        public string ToCurrency { get; set; }

        public decimal FromAmount { get; set; }

        public decimal ToAmount { get; set; }
    }
}
