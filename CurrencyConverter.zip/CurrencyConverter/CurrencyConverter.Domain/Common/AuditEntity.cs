﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Domain.Common
{
    public class AuditEntity
    {
        public DateTime DateCreated { get; set; }
    }
}
