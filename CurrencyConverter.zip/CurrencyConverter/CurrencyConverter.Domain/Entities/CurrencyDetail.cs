﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CurrencyConverter.Domain.Entities
{
    public class CurrencyDetail
    {
        public Guid Id { get; set; }

        public string FromCurrency { get; set; }

        public string ToCurrency { get; set; }

        public decimal FromAmount { get; set; }

        public decimal ToAmount { get; set; }
    }
}
